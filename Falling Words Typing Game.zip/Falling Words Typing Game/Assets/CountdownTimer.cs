﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CountdownTimer : MonoBehaviour {


    public float targetTime = 60f;
    public bool gameEnd = false;
    
    public Transform countTime;

    public void GameOver()
    {
        SceneManager.LoadScene(2);
    }

    void Update () {
        

        targetTime -= Time.deltaTime;
        countTime.GetComponent<TextMesh>().text = "Time left: "+targetTime;

        if (targetTime <= 0.0f)
        {
            gameEnd = true;
        }

        if (gameEnd == true)
        {
            GameOver();
        }
  
	}
}
