using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class WordManager : MonoBehaviour {

	public List<Word> words;

	public WordSpawner wordSpawner;

	private bool hasActiveWord;
	private Word activeWord;
    public int score = 0;
    public Transform countText;

    bool seen = false;
    
    public void AddWord ()
	{
		Word word = new Word(WordGenerator.GetRandomWord(), wordSpawner.SpawnWord());
		//Debug.Log(word.word);

		words.Add(word);
        countText.GetComponent<TextMesh>().text = "Score: " + score;

      
    }

	public void TypeLetter (char letter)
	{
		if (hasActiveWord)
		{
			if (activeWord.GetNextLetter() == letter)
			{
				activeWord.TypeLetter();
			}
		} else
		{
			foreach(Word word in words)
			{
				if (word.GetNextLetter() == letter)
				{
					activeWord = word;
					hasActiveWord = true;
					word.TypeLetter();
					break;
				}
			}
		}

		if (hasActiveWord && activeWord.WordTyped())
		{
            score = score + 1;
			hasActiveWord = false;
			words.Remove(activeWord);
            
            if (words.Remove(activeWord) == true)
            {
                countText.GetComponent<TextMesh>().text = "Score: " + score;
     
            }
            
        }

       
	}

    

   /* private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.name == "BottomBorder")
        {
            Debug.Log("Worked");
            SceneManager.LoadScene("Game Over");
        }
    }*/

}
