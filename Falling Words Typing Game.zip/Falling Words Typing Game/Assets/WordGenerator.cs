using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class WordGenerator : MonoBehaviour {

   

    public static string GetRandomWord()
    {
        string filePath = @"C:\\Users\\Kelsie\\Desktop\\NSU Spring 2019\\Game Programming\\RandomWords.txt";
        string text = System.IO.File.ReadAllText(filePath);
       
        string[] wordList = text.Split(' ');
        int randomIndex = Random.Range(0, wordList.Length);
        string randomWord = wordList[randomIndex];

        return randomWord;
    }
}
