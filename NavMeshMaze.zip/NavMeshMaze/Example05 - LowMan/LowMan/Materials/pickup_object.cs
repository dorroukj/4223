﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class pickup_object : MonoBehaviour
{
    public int score;
    public Transform Score;
    // Start is called before the first frame update
    private void OnTriggerEnter(Collider collider)
    {
        if (collider.gameObject.tag == "Player")
        {
            //score = score + 1;
            print("Item Picked up");
            Destroy(gameObject);
            Score.GetComponent<TextMesh>().text = "Score: " + (score+1);
        }

    }
}

  
