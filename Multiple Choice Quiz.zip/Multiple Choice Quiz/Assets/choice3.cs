﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class choice3 : MonoBehaviour {

    List<string> thirdChoice = new List<string>() { "Paris", "4", "Hey", "200", "Dog food" };

    // Use this for initialization
    void Start()
    {
        //GetComponent<TextMesh>().text = secondChoice[0];
    }

    // Update is called once per frame
    void Update()
    {
        if (textControl.randQuestion > -1)
        {
            GetComponent<TextMesh>().text = thirdChoice[textControl.randQuestion];
        }
    }
    void OnMouseDown()
    {
        textControl.selectedAnswer = gameObject.name;
        textControl.choiceSelected = "y";
        //Debug.Log(gameObject.name);
    }
}
