﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class choice1 : MonoBehaviour {

    List<string> firstChoice = new List<string>() { "Venice", "0", "Yo man", "87", "Pie" };

    // Use this for initialization
    void Start()
    {
        //GetComponent<TextMesh>().text = firstChoice[0];
    }

    // Update is called once per frame
    void Update()
    {
        if (textControl.randQuestion > -1)
        {
            GetComponent<TextMesh>().text = firstChoice[textControl.randQuestion];
        }
    }
    void OnMouseDown()
    {
        textControl.selectedAnswer = gameObject.name;
        textControl.choiceSelected = "y";
        //Debug.Log(gameObject.name);
    }
}
