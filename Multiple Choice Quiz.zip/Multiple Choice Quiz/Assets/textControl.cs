﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;


public class textControl : MonoBehaviour
{

    List<string> questions = new List<string>() { "What is the Capitol of Italy?", "What is 2+2 ?", "What is Spanish for 'hello'?", "What is 99+1 ?", "What do you eat on Thanksgiving?" };

    List<string> correctAnswer = new List<string>() { "1", "3", "4", "2", "1" };
    

    int score = 0;
    public Transform resultObj;

    public static string selectedAnswer;

    public static string choiceSelected = "no";


    public static int randQuestion = -1;

    void Start()
    {

       
    }


    void Update()
    {
        if (randQuestion == -1)
        {
            randQuestion = Random.Range(0, 5);
        }

        if (randQuestion > -1)
        {
            GetComponent<TextMesh>().text = questions[randQuestion];
        }

        if (choiceSelected == "y")
        {
            choiceSelected = "no";


            if (correctAnswer[randQuestion] == selectedAnswer)
            {
                score = score + 1;
                resultObj.GetComponent<TextMesh>().text = "Correct! Click Next to continue "+"Score: "+score;
                //questions.RemoveAt(randQuestion);
                //correctAnswer.RemoveAt(randQuestion);
            }
            else
            {
                resultObj.GetComponent<TextMesh>().text = "Incorrect. Click Next to continue" + "Score: " + score;
            }
        }

    }
}

